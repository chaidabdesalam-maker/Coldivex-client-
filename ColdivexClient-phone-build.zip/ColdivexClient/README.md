# COLDIVEX CLIENT — build project

This is an early Fabric client-mod project for Minecraft 1.21.11. It is a starter prototype, not a finished feature-complete client. It currently only registers a client entrypoint and logs that it loaded.

## Build

Use Java 21 and Gradle 9.2.1, then run:

```bash
gradle build
```

The remapped mod JAR is produced under `build/libs/`.

No anti-cheat bypass, stealth, or undetectability features are included or promised.
