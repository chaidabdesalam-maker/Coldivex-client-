package com.coldivex.client;

import net.fabricmc.api.ClientModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class ColdivexClient implements ClientModInitializer {
    public static final String MOD_ID = "coldivex";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitializeClient() {
        LOGGER.info("COLDIVEX CLIENT prototype loaded.");
    }
}
