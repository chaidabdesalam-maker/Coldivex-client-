package com.coldivex.client.gui;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** COLDIVEX's dark, green-accented module browser. Module switches are UI/config prototypes. */
public final class ColdivexScreen extends Screen {
    private static final int PANEL_W = 560;
    private static final int PANEL_H = 350;
    private static final int SIDEBAR_W = 142;
    private static final int BG = 0xF00B100D;
    private static final int SIDEBAR = 0xFF101813;
    private static final int CARD = 0xFF151E18;
    private static final int CARD_HOVER = 0xFF1C2A20;
    private static final int GREEN = 0xFF9BD6A9;
    private static final int MUTED = 0xFF829187;

    private final Map<String, List<String>> groups = new LinkedHashMap<>();
    private final Map<String, Boolean> enabled = new LinkedHashMap<>();
    private String selected = "Sword";
    private String search = "";
    private int scroll = 0;

    public ColdivexScreen() {
        super(Component.literal("COLDIVEX CLIENT"));
        groups.put("Sword", List.of("Aim Assist", "Trigger Bot", "Shield Breaker", "Fast Place", "Fast XP", "Sprint", "Keep Sprint", "Sprint Reset", "Jump Reset"));
        groups.put("Mace", List.of("Auto Mace", "Pearl Catch", "Perfect Wind Charge", "Breach Swap", "Auto Swap", "Spear Lunge"));
        groups.put("Donut SMP", List.of("X-Ray", "Chest ESP", "Player ESP", "Base Finder", "Block ESP"));
        groups.put("Visual", List.of("HUD", "Keystrokes", "CPS Counter", "Armor HUD", "FPS Counter", "Coordinates HUD"));
        groups.put("Settings", List.of("Open menu: Right Shift", "Theme: Emerald", "Save configuration"));
        for (List<String> modules : groups.values()) for (String module : modules) enabled.put(module, false);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderBackground(g, mouseX, mouseY, partialTick);
        int x = (width - PANEL_W) / 2;
        int y = (height - PANEL_H) / 2;
        // soft shadow and rounded-panel illusion
        g.fill(x - 3, y - 3, x + PANEL_W + 3, y + PANEL_H + 3, 0x70000000);
        g.fill(x, y, x + PANEL_W, y + PANEL_H, BG);
        g.fill(x, y, x + SIDEBAR_W, y + PANEL_H, SIDEBAR);
        g.fill(x + SIDEBAR_W, y, x + SIDEBAR_W + 1, y + PANEL_H, 0xFF26352B);

        g.drawString(font, "♛  COLDIVEX CLIENT", x + 15, y + 16, GREEN, false);
        g.drawString(font, "CLIENT BUILD  •  1.21.11", x + 16, y + 30, MUTED, false);
        g.drawString(font, "MODULES", x + 16, y + 55, MUTED, false);

        String[] nav = {"Sword", "Mace", "Donut SMP", "Visual"};
        int navY = y + 69;
        for (String item : nav) {
            boolean active = selected.equals(item);
            int rowY = navY;
            if (active) {
                g.fill(x + 8, rowY - 5, x + SIDEBAR_W - 8, rowY + 17, 0xFF26392C);
                g.fill(x + 8, rowY - 5, x + 10, rowY + 17, GREEN);
            }
            g.drawString(font, item, x + 19, rowY + 2, active ? 0xFFFFFFFF : 0xFFB6C0B8, false);
            g.drawString(font, String.valueOf(groups.get(item).size()), x + SIDEBAR_W - 26, rowY + 2, MUTED, false);
            navY += 29;
        }
        g.drawString(font, "GENERAL", x + 16, y + 205, MUTED, false);
        g.drawString(font, "⚙  Settings", x + 18, y + 224, 0xFFB6C0B8, false);
        g.drawString(font, "◈  Theme", x + 18, y + 246, 0xFFB6C0B8, false);
        g.drawString(font, "▣  Configs", x + 18, y + 268, 0xFFB6C0B8, false);
        g.drawString(font, "⌨  Keybinds", x + 18, y + 290, 0xFFB6C0B8, false);

        int contentX = x + SIDEBAR_W + 13;
        g.drawString(font, selected + " Modules", contentX, y + 17, 0xFFE7EEE8, false);
        g.drawString(font, groups.get(selected).size() + " modules  •  " + countEnabled(selected) + " enabled", contentX, y + 31, MUTED, false);
        g.fill(x + PANEL_W - 174, y + 12, x + PANEL_W - 13, y + 35, 0xFF18231C);
        g.drawString(font, "Search modules: " + search + (search.isEmpty() ? "_" : ""), x + PANEL_W - 166, y + 20, MUTED, false);
        g.drawString(font, "GAMEMODES", contentX + 3, y + 51, MUTED, false);

        int cardY = y + 70;
        int visibleBottom = y + PANEL_H - 13;
        int index = 0;
        for (String module : groups.get(selected)) {
            if (!search.isEmpty() && !module.toLowerCase().contains(search.toLowerCase())) continue;
            int cy = cardY + index * 43 - scroll;
            index++;
            if (cy < y + 63 || cy + 36 > visibleBottom) continue;
            boolean on = enabled.getOrDefault(module, false);
            boolean hover = mouseX >= contentX && mouseX <= x + PANEL_W - 13 && mouseY >= cy && mouseY <= cy + 35;
            g.fill(contentX, cy, x + PANEL_W - 13, cy + 36, hover ? CARD_HOVER : CARD);
            if (on) g.fill(contentX, cy + 5, contentX + 2, cy + 31, GREEN);
            g.drawString(font, module, contentX + 11, cy + 8, 0xFFE4ECE5, false);
            g.drawString(font, description(module), contentX + 11, cy + 21, MUTED, false);
            int sx = x + PANEL_W - 40;
            g.fill(sx - 3, cy + 10, sx + 3, cy + 25, on ? 0xFF527C5C : 0xFF28332B);
            g.fill(on ? sx : sx - 2, cy + 11, on ? sx + 10 : sx + 8, cy + 24, on ? GREEN : 0xFFDCE5DE);
        }
        super.render(g, mouseX, mouseY, partialTick);
    }

    private int countEnabled(String group) {
        int count = 0;
        for (String module : groups.get(group)) if (enabled.getOrDefault(module, false)) count++;
        return count;
    }

    private String description(String module) {
        return switch (module) {
            case "HUD" -> "Client information overlay";
            case "Keystrokes" -> "Display pressed movement keys";
            case "CPS Counter" -> "Show clicks per second";
            case "Armor HUD" -> "Display equipped armor";
            case "FPS Counter" -> "Show current frame rate";
            case "Coordinates HUD" -> "Show player coordinates";
            case "Sprint" -> "Sprint status indicator";
            case "Keep Sprint" -> "Sprint preference prototype";
            default -> "Module toggle prototype";
        };
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0) {
            int x = (width - PANEL_W) / 2;
            int y = (height - PANEL_H) / 2;
            if (mouseX >= x + 8 && mouseX <= x + SIDEBAR_W - 8) {
                String[] nav = {"Sword", "Mace", "Donut SMP", "Visual"};
                for (int i = 0; i < nav.length; i++) {
                    int rowY = y + 69 + i * 29;
                    if (mouseY >= rowY - 5 && mouseY <= rowY + 17) {
                        selected = nav[i]; scroll = 0; search = ""; return true;
                    }
                }
            }
            int contentX = x + SIDEBAR_W + 13;
            int cardY = y + 70;
            int index = 0;
            for (String module : groups.get(selected)) {
                if (!search.isEmpty() && !module.toLowerCase().contains(search.toLowerCase())) continue;
                int cy = cardY + index * 43 - scroll; index++;
                if (mouseX >= contentX && mouseX <= x + PANEL_W - 13 && mouseY >= cy && mouseY <= cy + 36) {
                    enabled.put(module, !enabled.getOrDefault(module, false)); return true;
                }
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        scroll = Math.max(0, Math.min(250, scroll - (int) (verticalAmount * 30)));
        return true;
    }

    @Override
    public boolean charTyped(char codePoint, int modifiers) {
        if (Character.isLetterOrDigit(codePoint) || codePoint == ' ') { search += codePoint; return true; }
        return super.charTyped(codePoint, modifiers);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_BACKSPACE && !search.isEmpty()) { search = search.substring(0, search.length() - 1); return true; }
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) { onClose(); return true; }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override public boolean isPauseScreen() { return false; }
}
