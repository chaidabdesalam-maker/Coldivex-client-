package com.coldivex.client;

import com.coldivex.client.gui.ColdivexScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class ColdivexClient implements ClientModInitializer {
    public static final String MOD_ID = "coldivex";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    private static KeyMapping openMenuKey;

    @Override
    public void onInitializeClient() {
        openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.coldivex.open_menu",
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.coldivex"
        ));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenuKey.consumeClick()) {
                if (client.screen == null) {
                    client.setScreen(new ColdivexScreen());
                } else if (client.screen instanceof ColdivexScreen) {
                    client.setScreen(null);
                }
            }
        });
        LOGGER.info("COLDIVEX CLIENT loaded. Press Right Shift to open the menu.");
    }
}
