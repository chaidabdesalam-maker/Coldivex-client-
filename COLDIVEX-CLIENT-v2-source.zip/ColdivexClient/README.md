# COLDIVEX CLIENT 2.0.0

Client-side Fabric GUI prototype for Minecraft 1.21.11 (Java 21). Press Right Shift to open the module browser.

The interface includes Sword, Mace, Donut SMP, Visual, Settings, Theme, Configs, and Keybinds sections, a module search field, scrollable cards, and clickable prototype toggles.

Important: most combat, ESP, X-Ray, and automation entries are visual/configuration placeholders, not implemented gameplay features. This build does not include anti-cheat bypass or stealth features.

Build with Gradle using the included project files. The resulting remapped Fabric mod should be tested in the target launcher before use.
